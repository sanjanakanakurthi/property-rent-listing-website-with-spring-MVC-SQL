package com.example.demo.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "properties")
public class Property {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;        // Property Title
    private String location;     // Location
    private String type;         // Property Type (Residential, Commercial, Land)
    private Double sqrRate;
    private Double price;        // Price
    private String address;      // Address
    private String description;  // Description
    private String image;        // Image URL

    // Constructors
    public Property() {
    }

    public Property(String title, String location, String type, Double sqrRate,
                    Double price, String address, String description, String image) {
        this.title = title;
        this.location = location;
        this.type = type;
        this.sqrRate = sqrRate;
        this.price = price;
        this.address = address;
        this.description = description;
        this.image = image;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double getSqrRate() {
        return sqrRate;
    }

    public void setSqrRate(Double sqrRate) {
        this.sqrRate = sqrRate;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
