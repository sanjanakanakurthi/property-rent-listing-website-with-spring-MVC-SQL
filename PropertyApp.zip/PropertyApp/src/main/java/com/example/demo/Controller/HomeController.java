package com.example.demo.Controller;

import com.example.demo.Entity.User;
import com.example.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class HomeController {

    @Autowired
    private UserService userService;

    // Home Page
    @GetMapping("/home")
    public String showHomePage() {
        return "home"; // templates/home.html
    }

    // Login Page (GET)
    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; // templates/login.html
    }

    // Login Form Submission (POST)
    @PostMapping("/login")
    public String processLogin(@RequestParam String email,
                               @RequestParam String password,
                               Model model) {
        // Optionally validate user with database
        // User user = userService.findByEmailAndPassword(email, password);
        // if (user == null) {
        //     model.addAttribute("error", "Invalid email or password");
        //     return "login";
        // }

        // Simulate login success
        return "dashboard"; // templates/dashboard.html
    }

    // Register Page (GET)
    @GetMapping("/register")
    public String showRegisterPage(Model model) {
        model.addAttribute("user", new User());
        return "register"; // templates/register.html
    }

    // Register Form Submission (POST)
    @PostMapping("/register")
    public String handleRegister(@ModelAttribute("user") User user) {
        userService.save(user); // Save new user
        return "redirect:/login"; // After registration, go to login
    }

    // Dashboard Page (GET)
    @GetMapping("/dashboard")
    public String showDashboardPage() {
        return "dashboard"; // templates/dashboard.html
    }
    @GetMapping("/about")
    public String about() {
        return "about"; // Ensure about.html exists in /templates
    }

}
