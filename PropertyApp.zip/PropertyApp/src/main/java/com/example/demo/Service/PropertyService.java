package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import com.example.demo.Entity.Property;

public interface PropertyService {
    Property save(Property property);
    List<Property> findAll();
    Optional<Property> findById(Long id);  // <-- Add this
    void delete(Long id);
}
