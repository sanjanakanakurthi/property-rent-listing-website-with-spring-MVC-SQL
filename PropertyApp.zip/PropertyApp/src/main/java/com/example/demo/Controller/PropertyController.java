package com.example.demo.Controller;

import com.example.demo.Entity.Property;
import com.example.demo.Service.PropertyService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/home/properties")
public class PropertyController {

    @Autowired
    private PropertyService propertyService;

    // ✅ List all properties
    @GetMapping
    public String getAllProperties(Model model) {
        List<Property> properties = propertyService.findAll();
        model.addAttribute("properties", properties);
        return "property_list"; // Must exist in templates/
    }

    // ✅ Show form to add new property
    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("property", new Property());
        return "property_add"; // Must exist in templates/
    }

    // ✅ Handle form submission
    @PostMapping
    public String addProperty(@ModelAttribute("property") Property property) {
        propertyService.save(property);
        return "redirect:/home/properties"; // Go back to list
    }

    // ✅ Edit form
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Property property = propertyService.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invalid property ID: " + id));
        model.addAttribute("property", property);
        return "property_add"; // Reuse same form
    }

    // ✅ Delete a property
    @GetMapping("/delete/{id}")
    public String deleteProperty(@PathVariable Long id) {
        propertyService.delete(id);
        return "redirect:/home/properties";
    }
}
