package com.example.demo.Controller;

import com.example.demo.Entity.User;
import com.example.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/home/users")
public class UserController {

    @Autowired
    private UserService userService;

    // ✅ Display user list
    @GetMapping
    public String showUserList(Model model) {
        model.addAttribute("users", userService.findAll());
        return "user_list"; // user_list.html
    }

    // ✅ Show add user form
    @GetMapping("/add/user")
    public String showAddUserForm(Model model) {
        model.addAttribute("user", new User());
        return "user_add"; // user_add.html
    }

    // ✅ Save new user
    @PostMapping("/save")
    public String saveUser(@ModelAttribute("user") User user) {
        userService.save(user);
        return "redirect:/home/users"; // Redirect to list
    }

    // ✅ Show edit user form
    @GetMapping("/edit/{id}")
    public String showEditUserForm(@PathVariable Long id, Model model) {
        User user = userService.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + id));
        model.addAttribute("user", user);
        return "user_add"; // Reuse the same form
    }

    // ✅ Delete user
    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userService.delete(id);
        return "redirect:/home/users";
    }
}
